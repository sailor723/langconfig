---
name: sales_analytics
description: Database schema and business logic for sales data analysis including customers, orders, and revenue.
---

# Sales Analytics Schema

## Tables

### customers
- customer_id (PRIMARY KEY)
- name
- email
- signup_date
- status (active/inactive)
- customer_tier (bronze/silver/gold/platinum)

### orders
- order_id (PRIMARY KEY)
- customer_id (FOREIGN KEY -> customers)
- order_date
- status (pending/completed/cancelled/refunded)
- total_amount
- sales_region (north/south/east/west)

### order_items
- item_id (PRIMARY KEY)
- order_id (FOREIGN KEY -> orders)
- product_id
- quantity
- unit_price
- discount_percent

## Business Logic

**Active customers**: status = 'active' AND signup_date <= CURRENT_DATE - INTERVAL '90 days'

**Revenue calculation**: Only count orders with status = 'completed'. Use total_amount from orders table, which already accounts for discounts.

**Customer lifetime value (CLV)**: Sum of all completed order amounts for a customer.

**High-value orders**: Orders with total_amount > 1000

## Example Query

```sql
-- Get top 10 customers by revenue in the last quarter
SELECT
  c.customer_id,
  c.name,
  c.customer_tier,
  SUM(o.total_amount) as total_revenue
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
WHERE o.status = 'completed'
  AND o.order_date >= CURRENT_DATE - INTERVAL '3 months'
GROUP BY c.customer_id, c.name, c.customer_tier
ORDER BY total_revenue DESC
LIMIT 10;
```

## Chart Generation

When the user asks for a chart or visualization, use the `generate_chart` tool.

**How to use generate_chart:**
1. First, write a SQL query that returns **2 columns**: label (1st column) and value (2nd column)
2. Call `generate_chart(sql, chart_type, title)` with the query
3. Example: After finding top customers by revenue, call `generate_chart` with a query like `SELECT name, total_revenue FROM ...` and `chart_type="bar"`

**Recommended chart types by scenario:**
- **bar**: Comparing values across categories (e.g., revenue by customer, revenue by region)
- **pie**: Showing percentage breakdowns (e.g., revenue by product category, customer tier distribution)
- **line**: Showing trends over time
- **horizontal_bar**: Many categories (6+ items) where labels are long
